import streamlit as st
from utils.ai_services import (
    generate_story, 
    extract_key_storyboard_prompts, 
    generate_storyboard_image,
    generate_video_from_story
)
import os
import time

# --- Page Setup ---
st.set_page_config(layout="wide", page_title="AI Story Generator", page_icon="🎬")

# --- UI Elements ---
st.title("🎬 AI Storyboard and Scene Generator")
st.markdown("From a simple idea to a visual story. Enter a topic and let the AI build the rest.")

# --- Folder Setup ---
if not os.path.exists("generated_media"):
    os.makedirs("generated_media")

# --- User Input ---
user_topic = st.text_input(
    label="Enter a topic, character, or scenario for your story:",
    value="A lonely astronaut on Mars discovers a mysterious, pulsating alien artifact."
)

# --- Main Application Logic ---
if st.button("Generate My Story", type="primary", use_container_width=True):
    
    # Steps 1 & 2: Story and Prompt Generation
    with st.spinner("Step 1 & 2: Gemini is writing your story and analyzing it..."):
        story_text = generate_story(user_topic)
        key_prompts = extract_key_storyboard_prompts(story_text)
    
    st.header("📜 Your Generated Story")
    st.write(story_text)
    st.divider()

    # Step 3: Sequential Image Generation
    st.header("🎨 Your AI-Generated Storyboard")
    cols = st.columns(4)
    
    for i, prompt in enumerate(key_prompts):
        with cols[i]:
            if prompt and "failed" not in prompt and "error" not in prompt:
                with st.status(f"Scene {i+1} processing...", expanded=True) as status:
                    st.write(f"Generating image {i+1}/4...")
                    image_filename = os.path.join("generated_media", f"scene_{i+1}.png")
                    
                    # Call the function and get the success status and result
                    success, result = generate_storyboard_image(prompt, image_filename)
                    
                    if success:
                        st.image(result, caption=f"Scene {i+1}")
                        status.update(label=f"Scene {i+1} complete!", state="complete", expanded=False)
                    else:
                        st.error(f"Image {i+1} failed:")
                        st.caption(f"Error: {result}", unsafe_allow_html=True)
                        status.update(label=f"Scene {i+1} failed!", state="error")
            else:
                st.warning(f"Skipping Image {i+1} due to an invalid prompt.")
        
        # Cooling period to respect API rate limits
        if i < len(key_prompts) - 1:
            with st.spinner('Cooldown period (15s)...'):
                time.sleep(15) 
            
    st.divider()

    # Step 4: Video Placeholder
    st.header("🎥 Your AI-Generated Video Scene")
    with st.spinner("Step 4: Checking video generation status..."):
        video_result_message = generate_video_from_story(story_text)
    
    st.info(video_result_message)

else:
    st.info("Click the 'Generate My Story' button to begin.")