import vertexai
from vertexai.generative_models import GenerativeModel
import os

# --- CONFIGURATION ---
PROJECT_ID = "vertex-test-466416"
LOCATION = "us-central1"
TEXT_MODEL_NAME = "gemini-2.5-flash"
IMAGE_MODEL_NAME = "imagegeneration@006"
VIDEO_MODEL_NAME = "videogeneration@001"

def initialize_vertex():
    """Initializes the Vertex AI SDK."""
    vertexai.init(project=PROJECT_ID, location=LOCATION)

def generate_story(topic: str) -> str:
    """Generates a short story based on a user's topic."""
    print("STEP 1: Initializing and calling the text model for story generation...")
    initialize_vertex()
    model = GenerativeModel(TEXT_MODEL_NAME)
    prompt = f"""
    You are a master storyteller. Based on the following topic, write a short,
    imaginative story of about 150 words. The story must have a clear beginning,
    a moment of discovery or action, and a resolution.

    TOPIC: "{topic}"

    STORY:
    """
    response = model.generate_content(prompt)
    print("STEP 1: Story generated successfully.")
    return response.text

def extract_key_storyboard_prompts(story: str) -> list[str]:
    """Uses Gemini to create 4 high-quality, visually descriptive image prompts."""
    print("STEP 2: Analyzing story to extract 4 key visual prompts...")
    initialize_vertex()
    model = GenerativeModel(TEXT_MODEL_NAME)
    
    prompt = f"""
    You are an expert prompt engineer for an AI image generator. Read the following story
    and identify the 4 most important, visually distinct moments. For each moment, create
    a detailed and descriptive prompt.

    Each prompt must include:
    - Subject: Who or what is the main focus.
    - Setting: A clear description of the background and environment.
    - Action: What the subject is doing.
    - Mood/Lighting: The feeling of the scene (e.g., "dramatic, moody lighting", "bright, optimistic sunshine").
    - Composition: How the shot is framed (e.g., "close-up shot", "wide angle landscape", "from a low angle").

    CRITICAL: Respond ONLY with a Python list of 4 strings. Do not add any other text.

    STORY:
    ---
    {story}
    ---

    YOUR_PROMPTS_LIST:
    """
    
    response = model.generate_content(prompt)
    print("STEP 2: Prompts extracted. Now cleaning up the response...")
    
    try:
        clean_response = response.text.strip().replace("```python", "").replace("```", "")
        prompts_list = eval(clean_response)
        if isinstance(prompts_list, list) and len(prompts_list) == 4:
            print("STEP 2: Successfully parsed 4 high-quality prompts.")
            return prompts_list
        else:
            return ["Parsing failed.", "", "", ""]
    except Exception as e:
        print(f"STEP 2: Error parsing prompts list - {e}")
        return ["Error creating prompts.", "", "", ""]

def generate_storyboard_image(prompt: str, output_filename: str) -> tuple[bool, str]:
    """
    Generates one image and returns a tuple: (success_boolean, result_string).
    'result_string' is the filename on success, or the error message on failure.
    """
    print(f"\n--- DEBUG: ATTEMPTING IMAGE GENERATION ---")
    print(f"PROMPT BEING SENT: {prompt}")

    try:
        initialize_vertex()
        model = GenerativeModel(model_name=IMAGE_MODEL_NAME)
        final_prompt = f"{prompt}, cinematic film still, epic, ultra-realistic, 8k"

        # The corrected API call without the invalid 'generation_config' parameter
        response = model.generate_content([final_prompt])
        
        image_bytes = response.candidates[0].content.parts[0].data
        with open(output_filename, "wb") as f:
            f.write(image_bytes)
        
        print(f"SUCCESS: Image saved to {output_filename}")
        return (True, output_filename)

    except Exception as e:
        error_message = str(e)
        print(f"ERROR: Image generation failed.")
        print(f"FULL ERROR DETAILS: {error_message}")
        return (False, error_message)

def generate_video_from_story(story_text: str) -> str:
    """This is the placeholder function for video generation."""
    print("STEP 4: Entering video generation function (currently a placeholder).")
    message = """
    **Video Generation is Pending Quota Approval.**
    
    The final code for video generation is ready. Once Google approves your project's quota 
    increase for the `videogeneration` model, this step will be enabled.
    """
    return message